package com.ctrip.sysdev.msg;

import java.util.List;
import java.util.Map;


public class MessageObject {

  // public MyEnum action;

  public MessageType messageType;

  public ActionType actionType;

  public boolean useCache;

  public String SPName;

  public Map<String, AvailableType> SPKVParams;

  public Map<String, List<AvailableType>> BulkSQL;

}
