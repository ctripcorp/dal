
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Arch.Data;
using Arch.Data.DbEngine;
using com.ctrip.platform.tools.Entity.DataModel;

namespace com.ctrip.platform.tools.Dao
{
    public partial class spASDPHotelRoomCalendarPricei_genDao
    {
        readonly BaseDao baseDao = BaseDaoFactory.CreateBaseDao("");

        /// <summary>
        ///  执行SPspASDPHotelRoomCalendarPricei_gen
        /// </summary>
        /// <param name="spASDPHotelRoomCalendarPricei_gen">spASDPHotelRoomCalendarPricei_gen实体对象</param>
        /// <returns>影响的行数</returns>
        public int ExecspASDPHotelRoomCalendarPricei_gen(spASDPHotelRoomCalendarPricei_gen spASDPHotelRoomCalendarPricei_gen)
        {
            try
            {
                StatementParameterCollection parameters = new StatementParameterCollection();
                parameters.Add(new StatementParameter{ Name = "@HotelID", Direction = ParameterDirection.Input, DbType = DbType.Int32, Value = spASDPHotelRoomCalendarPricei_gen.Hotelid});
                parameters.Add(new StatementParameter{ Name = "@RoomID", Direction = ParameterDirection.Input, DbType = DbType.Int32, Value = spASDPHotelRoomCalendarPricei_gen.Roomid});
                parameters.Add(new StatementParameter{ Name = "@DayPrice1", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice1});
                parameters.Add(new StatementParameter{ Name = "@DayPrice2", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice2});
                parameters.Add(new StatementParameter{ Name = "@DayPrice3", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice3});
                parameters.Add(new StatementParameter{ Name = "@DayPrice4", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice4});
                parameters.Add(new StatementParameter{ Name = "@DayPrice5", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice5});
                parameters.Add(new StatementParameter{ Name = "@DayPrice6", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice6});
                parameters.Add(new StatementParameter{ Name = "@DayPrice7", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice7});
                parameters.Add(new StatementParameter{ Name = "@DayPrice8", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice8});
                parameters.Add(new StatementParameter{ Name = "@DayPrice9", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice9});
                parameters.Add(new StatementParameter{ Name = "@DayPrice10", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice10});
                parameters.Add(new StatementParameter{ Name = "@DayPrice11", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice11});
                parameters.Add(new StatementParameter{ Name = "@DayPrice12", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice12});
                parameters.Add(new StatementParameter{ Name = "@DayPrice13", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice13});
                parameters.Add(new StatementParameter{ Name = "@DayPrice14", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice14});
                parameters.Add(new StatementParameter{ Name = "@DayPrice15", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice15});
                parameters.Add(new StatementParameter{ Name = "@DayPrice16", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice16});
                parameters.Add(new StatementParameter{ Name = "@DayPrice17", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice17});
                parameters.Add(new StatementParameter{ Name = "@DayPrice18", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice18});
                parameters.Add(new StatementParameter{ Name = "@DayPrice19", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice19});
                parameters.Add(new StatementParameter{ Name = "@DayPrice20", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice20});
                parameters.Add(new StatementParameter{ Name = "@DayPrice21", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice21});
                parameters.Add(new StatementParameter{ Name = "@DayPrice22", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice22});
                parameters.Add(new StatementParameter{ Name = "@DayPrice23", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice23});
                parameters.Add(new StatementParameter{ Name = "@DayPrice24", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice24});
                parameters.Add(new StatementParameter{ Name = "@DayPrice25", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice25});
                parameters.Add(new StatementParameter{ Name = "@DayPrice26", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice26});
                parameters.Add(new StatementParameter{ Name = "@DayPrice27", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice27});
                parameters.Add(new StatementParameter{ Name = "@DayPrice28", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice28});
                parameters.Add(new StatementParameter{ Name = "@DayPrice29", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice29});
                parameters.Add(new StatementParameter{ Name = "@DayPrice30", Direction = ParameterDirection.Input, DbType = DbType.Decimal, Value = spASDPHotelRoomCalendarPricei_gen.Dayprice30});
                parameters.Add(new StatementParameter{ Name = "@Begin_DataTime", Direction = ParameterDirection.Input, DbType = DbType.DateTime2, Value = spASDPHotelRoomCalendarPricei_gen.Begin_datatime});
                parameters.Add(new StatementParameter{ Name = "@return",  Direction = ParameterDirection.ReturnValue});

                baseDao.ExecSp("dbo.spA_SDP_HotelRoom_CalendarPrice_i", parameters);

                return (int)parameters["@return"].Value;
            }
            catch (Exception ex)
            {
                throw new DalException("调用spASDPHotelRoomCalendarPricei_genDao时，访问ExecspASDPHotelRoomCalendarPricei_gen时出错", ex);
            }

       }

    }
}
