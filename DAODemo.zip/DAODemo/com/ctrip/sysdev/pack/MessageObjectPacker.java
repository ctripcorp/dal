package com.ctrip.sysdev.pack;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.msgpack.MessagePack;
import org.msgpack.packer.Packer;

import com.ctrip.sysdev.msg.AvailableType;
import com.ctrip.sysdev.msg.MessageObject;

public class MessageObjectPacker {

	public byte[] pack(MessageObject msg) throws Exception {

		ByteArrayOutputStream out = new ByteArrayOutputStream();

		MessagePack msgpack = new MessagePack();

		Packer packer = msgpack.createPacker(out);

		packer.writeArrayBegin(6);

		packer.write(msg.messageType.getIntVal());

		packer.write(msg.actionType.getIntVal());

		packer.write(msg.useCache);

		packer.write(msg.SPName);

		// BEGIN stored procedure params pack ----------------------
		packer.writeMapBegin(msg.SPKVParams.size());
		for (String key : msg.SPKVParams.keySet()) {
			packer.write(key);

			AvailableType availableType = msg.SPKVParams.get(key);
			// write available type
			packer.writeArrayBegin(2);
			packer.write(availableType.current.getIntVal());
			switch (availableType.current) {
			case INT:
				packer.write(availableType.int_arg);
				break;
			case LONG:
				packer.write(availableType.long_arg);
				break;
			case STRING:
				packer.write(availableType.string_arg);
				break;
			case BOOL:
				packer.write(availableType.bool_arg);
				break;
			case BYTEARR:
				packer.write(availableType.bytearr_arg);
				break;
			case DOUBLE:
				packer.write(availableType.double_arg);
				break;
			}
			packer.writeArrayEnd();
		}
		packer.writeMapEnd();
		// END stored procedure params pack ----------------------
		
		// BEGIN bulk sqls pack ----------------------
		packer.writeMapBegin(msg.BulkSQL.size());
		for (String key : msg.BulkSQL.keySet()) {
			packer.write(key);

			List<AvailableType> availableType = msg.BulkSQL.get(key);
			// write available type
			packer.writeArrayBegin(availableType.size());
			
			for (AvailableType at : availableType) {
				packer.writeArrayBegin(2);
				
				packer.write(at.current.getIntVal());
				switch (at.current) {
				case INT:
					packer.write(at.int_arg);
					break;
				case LONG:
					packer.write(at.long_arg);
					break;
				case STRING:
					packer.write(at.string_arg);
					break;
				case BOOL:
					packer.write(at.bool_arg);
					break;
				case BYTEARR:
					packer.write(at.bytearr_arg);
					break;
				case DOUBLE:
					packer.write(at.double_arg);
					break;
				}
				packer.writeArrayEnd();
			}
			packer.writeArrayEnd();
		}
		packer.writeMapEnd();
		// END bulk sqls pack ----------------------

		packer.writeArrayEnd();

		return out.toByteArray();
	}

}
