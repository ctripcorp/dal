package com.ctrip.sysdev;

public class Consts {
	
	 public static final String serverAddr = "127.0.0.1";
     public static final int serverPort = 9000;
     public static final int protocolVersion = 1;
     public static final int databaseId = 32;
     public static final String credential = "user=link;password=snow";

}
