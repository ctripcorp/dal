package com.ctrip.sysdev.msg;

public enum AvailableEnum {
	
	INT(0),
	LONG(1),
	STRING(2),
	BOOL(3),
	BYTEARR(4),
	DOUBLE(5); 

	private int intVal;

	AvailableEnum(int intVal) {
		this.intVal = intVal;
	}

	public int getIntVal() {
		return intVal;
	}

}
