package com.ctrip.sysdev.msg;

public enum ActionType {
	
	SELECT(0),
	INSERT(1),
	UPDATE(2),
	DELETE(3);

	private int intVal;

	ActionType(int intVal) {
		this.intVal = intVal;
	}

	public int getIntVal() {
		return intVal;
	}
}
