using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Arch.Data;
using Arch.Data.DbEngine;
using com.ctrip.platform.tools.Entity.DataModel;

namespace com.ctrip.platform.tools.Dao
{
    public partial class QueryDao
    {
        readonly BaseDao baseDao = BaseDaoFactory.CreateBaseDao("daogen");

		/// <summary>
        ///  getServerById
        /// </summary>
        /// <param name="1"></param>
        /// <returns></returns>
        public IList<Query> getServerById(uint 1)
        {
        	try
            {
            	string sql = "select id, driver, server,port,domain, user,password, db_type from daogen.data_source WHERE id = ?";
                StatementParameterCollection parameters = new StatementParameterCollection();
                parameters.Add(new StatementParameter{ Name = "@1", Direction = ParameterDirection.Input, DbType = DbType.UInt32, Value =1 });
				//���ֻ��Ҫһ����¼������ʹ��limit 1����top 1����ʹ��SelectFirst�������
				//return baseDao.SelectFirst<Query>(sql, parameters);
                return baseDao.SelectList<Query>(sql, parameters);

            }
            catch (Exception ex)
            {
                throw new DalException("����QueryDaoʱ������getServerByIdʱ����", ex);
            }
        }

    }
}