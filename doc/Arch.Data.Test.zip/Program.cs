﻿using System;

namespace Arch.Data.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            BaseDao dao = BaseDaoFactory.CreateBaseDao("dao_test");
            var result = dao.SelectDataTable("select 1");
            Console.Read();
        }
    }
}