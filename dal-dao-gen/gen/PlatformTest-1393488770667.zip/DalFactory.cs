using com.ctrip.platform.tools.Interface.IDao;
using com.ctrip.platform.tools.Dao;

namespace com.ctrip.platform.tools
{
	/// <summary>
    /// DALFactory
    /// </summary>
	public partial class DALFactory
	{
        private static readonly IPerson_genDao person_genDao = new Person_genDao();

		/// <summary>
        /// Property Person_genDao
        /// </summary>
		public static IPerson_genDao Person_genDao
        {
            get
            {
                return person_genDao;
            }
        }
        private static readonly ISDP_SH_PriceBatch_genDao sDP_SH_PriceBatch_genDao = new SDP_SH_PriceBatch_genDao();

		/// <summary>
        /// Property SDP_SH_PriceBatch_genDao
        /// </summary>
		public static ISDP_SH_PriceBatch_genDao SDP_SH_PriceBatch_genDao
        {
            get
            {
                return sDP_SH_PriceBatch_genDao;
            }
        }
	}
}