package com.ctrip.sysdev.msg;

public enum MessageType {

	SQL(0), // T-SQL
	SP(1); // Stored Procedure

	private int intVal;

	MessageType(int intVal) {
		this.intVal = intVal;
	}

	public int getIntVal() {
		return intVal;
	}

}
