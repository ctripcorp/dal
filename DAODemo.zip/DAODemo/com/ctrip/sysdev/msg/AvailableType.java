package com.ctrip.sysdev.msg;

public class AvailableType {
	public AvailableEnum current;
	public int int_arg;
	public long long_arg;
	public String string_arg;
	public boolean bool_arg;
	public byte[] bytearr_arg;
	public double double_arg;
}
