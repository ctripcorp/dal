using System;
using Arch.Data.Orm;

namespace com.ctrip.platform.tools.Entity.DataModel
{
	/// <summary>
    /// dbo.spA_SDP_HotelRoom_CalendarPrice_i
    /// </summary>
	[Serializable]
	public partial class spASDPHotelRoomCalendarPricei_gen
	{
        /// <summary>
        /// HotelID
        /// </summary>
		public int HotelID { get; set; }
        /// <summary>
        /// RoomID
        /// </summary>
		public int RoomID { get; set; }
        /// <summary>
        /// DayPrice1
        /// </summary>
		public decimal DayPrice1 { get; set; }
        /// <summary>
        /// DayPrice2
        /// </summary>
		public decimal DayPrice2 { get; set; }
        /// <summary>
        /// DayPrice3
        /// </summary>
		public decimal DayPrice3 { get; set; }
        /// <summary>
        /// DayPrice4
        /// </summary>
		public decimal DayPrice4 { get; set; }
        /// <summary>
        /// DayPrice5
        /// </summary>
		public decimal DayPrice5 { get; set; }
        /// <summary>
        /// DayPrice6
        /// </summary>
		public decimal DayPrice6 { get; set; }
        /// <summary>
        /// DayPrice7
        /// </summary>
		public decimal DayPrice7 { get; set; }
        /// <summary>
        /// DayPrice8
        /// </summary>
		public decimal DayPrice8 { get; set; }
        /// <summary>
        /// DayPrice9
        /// </summary>
		public decimal DayPrice9 { get; set; }
        /// <summary>
        /// DayPrice10
        /// </summary>
		public decimal DayPrice10 { get; set; }
        /// <summary>
        /// DayPrice11
        /// </summary>
		public decimal DayPrice11 { get; set; }
        /// <summary>
        /// DayPrice12
        /// </summary>
		public decimal DayPrice12 { get; set; }
        /// <summary>
        /// DayPrice13
        /// </summary>
		public decimal DayPrice13 { get; set; }
        /// <summary>
        /// DayPrice14
        /// </summary>
		public decimal DayPrice14 { get; set; }
        /// <summary>
        /// DayPrice15
        /// </summary>
		public decimal DayPrice15 { get; set; }
        /// <summary>
        /// DayPrice16
        /// </summary>
		public decimal DayPrice16 { get; set; }
        /// <summary>
        /// DayPrice17
        /// </summary>
		public decimal DayPrice17 { get; set; }
        /// <summary>
        /// DayPrice18
        /// </summary>
		public decimal DayPrice18 { get; set; }
        /// <summary>
        /// DayPrice19
        /// </summary>
		public decimal DayPrice19 { get; set; }
        /// <summary>
        /// DayPrice20
        /// </summary>
		public decimal DayPrice20 { get; set; }
        /// <summary>
        /// DayPrice21
        /// </summary>
		public decimal DayPrice21 { get; set; }
        /// <summary>
        /// DayPrice22
        /// </summary>
		public decimal DayPrice22 { get; set; }
        /// <summary>
        /// DayPrice23
        /// </summary>
		public decimal DayPrice23 { get; set; }
        /// <summary>
        /// DayPrice24
        /// </summary>
		public decimal DayPrice24 { get; set; }
        /// <summary>
        /// DayPrice25
        /// </summary>
		public decimal DayPrice25 { get; set; }
        /// <summary>
        /// DayPrice26
        /// </summary>
		public decimal DayPrice26 { get; set; }
        /// <summary>
        /// DayPrice27
        /// </summary>
		public decimal DayPrice27 { get; set; }
        /// <summary>
        /// DayPrice28
        /// </summary>
		public decimal DayPrice28 { get; set; }
        /// <summary>
        /// DayPrice29
        /// </summary>
		public decimal DayPrice29 { get; set; }
        /// <summary>
        /// DayPrice30
        /// </summary>
		public decimal DayPrice30 { get; set; }
        /// <summary>
        /// Begin_DataTime
        /// </summary>
		public DateTime Begin_DataTime { get; set; }
	}
}